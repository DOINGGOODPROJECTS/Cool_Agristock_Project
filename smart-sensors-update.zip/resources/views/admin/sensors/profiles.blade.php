<x-app-layout>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">@lang('locale.nav_sensor_profiles')</h4>
                <div class="page-title-right">
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#new-profile"><i class="fas fa-cart-plus"></i> @lang('locale.add')</button>
                </div>
            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <table class="table table-sm table-hover table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>@lang('locale.sensor_product')</th>
                                <th>@lang('locale.sensor_min_temperature')</th>
                                <th>@lang('locale.sensor_max_temperature')</th>
                                <th>@lang('locale.sensor_min_rh')</th>
                                <th>@lang('locale.sensor_max_rh')</th>
                                <th>@lang('locale.sensor_in_use_at')</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse ($profiles as $profile)
                                <tr>
                                    <td>{{ $profile->product->name ?? '—' }}</td>
                                    <td>{{ $profile->min_temperature ?? '—' }}</td>
                                    <td>{{ $profile->max_temperature ?? '—' }}</td>
                                    <td>{{ $profile->min_rh ?? '—' }}</td>
                                    <td>{{ $profile->max_rh ?? '—' }}</td>
                                    <td>{{ ($inUseAt[$profile->product_id] ?? collect())->join(', ') ?: '—' }}</td>
                                </tr>
                            @empty
                                <tr><td colspan="6" class="text-center text-muted py-3">—</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="new-profile">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-primary-subtle">
                    <h5 class="modal-title">@lang('locale.sensor_new_profile')</h5>
                </div>
                <form action="{{ route('sensor-profiles.store') }}" method="post">
                    <div class="modal-body">
                        @csrf
                        <div class="d-grid gap-3">
                            <select class="form-select" name="product_id" required>
                                <option value="" disabled selected>@lang('locale.sensor_product')</option>
                                @foreach ($products as $product)
                                    <option value="{{ $product->id }}">{{ $product->name }}</option>
                                @endforeach
                            </select>
                            <div class="row">
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <div class="form-floating">
                                        <input type="number" step="0.1" class="form-control" name="min_temperature" placeholder="Ex: 45"/> <label>@lang('locale.sensor_min_temperature')</label>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <div class="form-floating">
                                        <input type="number" step="0.1" class="form-control" name="max_temperature" placeholder="Ex: 55"/> <label>@lang('locale.sensor_max_temperature')</label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <div class="form-floating">
                                        <input type="number" step="0.1" class="form-control" name="min_rh" placeholder="Ex: 10"/> <label>@lang('locale.sensor_min_rh')</label>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <div class="form-floating">
                                        <input type="number" step="0.1" class="form-control" name="max_rh" placeholder="Ex: 40"/> <label>@lang('locale.sensor_max_rh')</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-primary">@lang('locale.submit') <i class="fas fa-check"></i></button>
                        <button class="btn btn-outline-danger" data-bs-dismiss="modal" type="button">@lang('locale.close') <i class="mdi mdi-close"></i></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</x-app-layout>
