<?php

namespace Database\Seeders;

use App\Models\EnvironmentalProfile;
use App\Models\Product;
use Illuminate\Database\Seeder;

/**
 * Populates recommended drying/storage temperature and RH ranges for
 * products that already exist in the `products` table, matched by name
 * (case-insensitive). Products with no name match here are left
 * untouched — this only fills in a profile, it never creates a product.
 *
 * Safe to re-run: existing profiles for a matched product are updated in
 * place (updateOrCreate), never duplicated.
 *
 * Reference values mirror the product catalog already curated in the Cool
 * Agristock smart-monitoring dashboard (dashboard.agricarecentres.com).
 */
class EnvironmentalProfileReferenceSeeder extends Seeder
{
    private const REFERENCE = [
        'Chilli' => ['min_temperature' => 30, 'max_temperature' => 45, 'min_rh' => 10, 'max_rh' => 20],
        'Okra' => ['min_temperature' => 35, 'max_temperature' => 45, 'min_rh' => 10, 'max_rh' => 20],
        'Ginger' => ['min_temperature' => 35, 'max_temperature' => 50, 'min_rh' => 8, 'max_rh' => 15],
        'Tomato' => ['min_temperature' => 12, 'max_temperature' => 20, 'min_rh' => 85, 'max_rh' => 90],
        'Mango' => ['min_temperature' => 2, 'max_temperature' => 8, 'min_rh' => 85, 'max_rh' => 95],
        'Pineapple' => ['min_temperature' => 7, 'max_temperature' => 10, 'min_rh' => 85, 'max_rh' => 90],
        'Avocado' => ['min_temperature' => 5, 'max_temperature' => 13, 'min_rh' => 85, 'max_rh' => 95],
        'Green pepper' => ['min_temperature' => 7, 'max_temperature' => 10, 'min_rh' => 90, 'max_rh' => 95],
        'Maize' => ['min_temperature' => 15, 'max_temperature' => 30, 'min_rh' => 0, 'max_rh' => 14],
        'Cassava' => ['min_temperature' => 30, 'max_temperature' => 40, 'min_rh' => 10, 'max_rh' => 20],
        'Groundnut' => ['min_temperature' => 15, 'max_temperature' => 28, 'min_rh' => 0, 'max_rh' => 12],
        'Cowpea' => ['min_temperature' => 15, 'max_temperature' => 28, 'min_rh' => 0, 'max_rh' => 13],
        'Sorghum' => ['min_temperature' => 15, 'max_temperature' => 30, 'min_rh' => 0, 'max_rh' => 13],
    ];

    public function run(): void
    {
        foreach (self::REFERENCE as $name => $range) {
            $product = Product::whereRaw('LOWER(name) = ?', [strtolower($name)])->first();

            if (! $product) {
                continue;
            }

            EnvironmentalProfile::updateOrCreate(['product_id' => $product->id], $range);
        }
    }
}
