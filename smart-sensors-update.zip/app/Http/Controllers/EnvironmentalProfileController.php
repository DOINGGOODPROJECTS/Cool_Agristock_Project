<?php

namespace App\Http\Controllers;

use App\Models\EnvironmentalProfile;
use App\Models\InventoryStock;
use App\Models\Product;
use Illuminate\Http\Request;

class EnvironmentalProfileController extends Controller
{
    public function index()
    {
        app()->setLocale(auth()->user()->language);

        $profiles = EnvironmentalProfile::with('product')->get();
        $products = Product::orderBy('name')->get();

        // Which storage locations currently hold stock of each product —
        // mirrors the "In use at" column on the partner smart-monitoring
        // dashboard, computed the same way: live, not stored.
        $inUseAt = InventoryStock::where('quantity', '>', 0)
            ->with('storage')
            ->get()
            ->groupBy('product_id')
            ->map(fn ($rows) => $rows->pluck('storage.location')->filter()->unique()->values());

        return view('admin.sensors.profiles', compact('profiles', 'products', 'inUseAt'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'product_id'      => 'required|integer|exists:products,id',
            'min_temperature' => 'nullable|numeric',
            'max_temperature' => 'nullable|numeric',
            'min_rh'          => 'nullable|numeric|min:0|max:100',
            'max_rh'          => 'nullable|numeric|min:0|max:100',
            'min_airflow'     => 'nullable|numeric|min:0',
        ]);

        EnvironmentalProfile::updateOrCreate(['product_id' => $data['product_id']], $data);

        return redirect()->back()->with('success', 'Environmental profile saved successfully');
    }

    public function update(Request $request, string $id)
    {
        $profile = EnvironmentalProfile::findOrFail($id);

        $data = $request->validate([
            'min_temperature' => 'nullable|numeric',
            'max_temperature' => 'nullable|numeric',
            'min_rh'          => 'nullable|numeric|min:0|max:100',
            'max_rh'          => 'nullable|numeric|min:0|max:100',
            'min_airflow'     => 'nullable|numeric|min:0',
        ]);

        $profile->update($data);

        return redirect()->back()->with('success', 'Environmental profile updated successfully');
    }

    public function destroy(string $id)
    {
        EnvironmentalProfile::findOrFail($id)->delete();

        return redirect()->back()->with('success', 'Environmental profile deleted successfully');
    }
}
